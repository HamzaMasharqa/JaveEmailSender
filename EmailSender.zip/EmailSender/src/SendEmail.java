import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {

	public void Sendemail(String n, String e) {

		String from = "ham.ham258951@gmail.com";
		String to = e.toString();
		String subject = "Test";

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", "587");
		Session session = Session.getDefaultInstance(props);

		try {
			InternetAddress fromAddress = new InternetAddress(from);
			InternetAddress toAddress = new InternetAddress(to);

			Message message = new MimeMessage(session);
			message.setFrom(fromAddress);
			message.setRecipient(Message.RecipientType.TO, toAddress);
			message.setSubject(subject);

			String sb = "<head>" + "<style type=\"text/css\">" + "  .red { color: #f00; }" + "</style>" + "</head>"
					+ "<h1 class=\"red\">" + message.getSubject() + "</h1>" + "<p>" + " Hello       " + n.toString()
					+ "<br><br></br> This is a test for sending messages through Java </br> " + "I hope that it worked  <strong>"
					+ "</strong>.</p>"+"<p>Thanks for understanding </p>";
			message.setContent(sb, "text/html; charset=utf-8");
			message.saveChanges();

			Transport.send(message, "ham.ham258951@gmail.com", "hamzah897936hamzah");
		} catch (MessagingException e1) {
			e1.printStackTrace();
		}
	}
}
